using Il2CppSystem.Collections.Generic;
using System.Linq;
using Object = UnityEngine.Object;
using UColor = UnityEngine.Color;
using System.Collections;
using TMPro;

namespace TownOfUsFusion.Patches;

public class Info
{
    public string Name { get; }
    public string Short { get; set; }
    public string Description { get; set; }
    public UColor Color { get; set; }
    public InfoType Type { get; }
    public bool Header { get; }

    public static readonly List<Info> AllInfo = new();

    public Info(string name, string shortF, string description, UColor color, InfoType type, bool header = false)
    {
        Name = name;
        Short = shortF;
        Description = description;
        Color = color;
        Type = type;
        Header = header;
    }

    public static void SetAllInfo() => AllInfo.AddRanges(GuideInfo.AllRoles, GuideInfo.AllModifiers, GuideInfo.AllFactions);

    public static string ColorIt(string result, bool bold = true)
    {
        foreach (var info in AllInfo.Where(x => x.Type is not (InfoType.Alignment)))
            result = result.Replace(info.Name, $"<b><color=#{info.Color.ToHtmlStringRGBA()}>{info.Name}</color></b>");

        for (var i = 0; i < 56; i++)
            result = result.Replace(((Alignment)i).AlignmentName(), $"<b>{((Alignment)i).AlignmentName(true)}</b>");

        result = result.Replace($"<b><color=#FFD700FF>Role</color></b> List", "Role List");

        if (!bold)
            result = result.Replace("<b>", "").Replace("</b>", "");

        return result;
    }

    public virtual void GuideEntry(out string result) => result = "";
}

public class RoleInfo : Info
{
    public string Alignment { get; }
    public string ColoredAlignment { get; }
    public string WinCon { get; }
    public Faction Faction { get; }
    public RoleEnum Role { get; }

    private const string ImpostorObjective = "Have a critical sabotage set off by the Impostors reach 0 seconds or kill off all Unfaithful Impostors, Crew and opposing Neutrals.";
    private const string CrewObjective = "Finish tasks along with other Crew or kill off all Impostors, Unfaithful Crew, and opposing Neutrals.";

    public RoleInfo(string name, string shortF, string description, Alignment alignmentEnum, Faction faction, UColor color, RoleEnum role,
        string wincon = "", bool header = false) : base(name, shortF, description, color, InfoType.Role, header)
    {
        Faction = faction;
        Role = role;
        Alignment = alignmentEnum.AlignmentName();
        ColoredAlignment = alignmentEnum.AlignmentName(true);
        WinCon = faction switch
        {
            Faction.Crewmates => CrewObjective,
            Faction.Impostors => ImpostorObjective,
            Faction.Neutrals => wincon,
            _ => "Invalid"
        };
    }

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += ColorIt($"Name: {Name}");
        result += "\n" + ColorIt($"Short Form: {Short}");
        result += $"\nAlignment: {ColoredAlignment}";
        result += "\n" + ColorIt(Utils.WrapText($"Win Condition: {WinCon}"));
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}

public class FactionInfo : Info
{
    private const string CrewDescription = "Each member has a special ability which determines who’s who and can help weed out the evils. The main theme of this faction is deduction and " +
        "goodwill. This faction is an uninformed majority meaning they make up most of the players and don't who the other members are. The Crew can do tasks which sort of act like a timer "
        + "for non-Crew roles.";
    private const string ImpostorDescription = "Each member of this faction has the ability to kill alongside an ability pertaining to their role. The main theme of this faction is " +
        "destruction and raw power. This faction is an informed minority meaning they make up a tiny fraction of the crew and know who the other members are. All members can sabotage to " +
        "distract the Crew from their tasks.";
    private const string NeutralDescription = "Neutrals are essentially factionless. Each member of this faction has their own unique way to win, seperate from the other roles in the same " +
        "faction. The main theme of this faction is free for all. This faction is an uninformed minority of the game, meaning they make up a small part of the crew while not knowing who the "
        + "other members are. Each role is unique in its own way, some can be helpful, some exist to destroy others and some just exist for the sake of existing.";

    public Faction Faction { get; }

    public FactionInfo(Faction faction, bool header = false) : base($"{faction}", "", "", default, InfoType.Faction, header)
    {
        Faction = faction;
        (Description, Short, Color) = faction switch
        {
            Faction.Crewmates => (CrewDescription, "Crew", Colors.Crewmate),
            Faction.Impostors => (ImpostorDescription, "Imp", Colors.Impostor),
            Faction.Neutrals => (NeutralDescription, "Newt", Colors.Neutral),
            _ => ("Invalid", "Invalid", Colors.Faction)
        };
    }

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += ColorIt($"Name: {Name}");
        result += "\n" + ColorIt($"Short Form: {Short}");
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}

public class AlignmentInfo : Info
{
    private const string CADescription = "Crew (Astral) roles have the ability to utilize spiritual powers to understand their surroundings.";
    private const string CrPDescription = "Crew (Protective) roles have the capability to stop someone from losing their life or bring back the dead.";
    private const string CIDescription = "Crew (Investigative) roles have the ability to gain information via special methods. Using the acquired info, Crew (Investigative) roles "
        + "can deduce who is good and who is not.";
    private const string CCDescription = "Crew (Chaos) roles are roles with abilities that can alter how players interact.";
    private const string CSDescription = "Crew (Support) roles are roles with miscellaneous abilities. Try not to get lost because if you are not paying attention, your chances " +
        "of winning will be severely decreased because of them.";
    private const string CKDescription = "Crew (Killing) roles have no aversion to killing like the rest of the Crew and if left alone and potentially wreck the chances of evils winning.";
    private const string CrPowDescription = "Crew (Power) roles are defected Syndicate (Power) roles who have sided with the Crew.";

    private const string ISDescription = "Impostor (Support) roles have miscellaneous abilities. These roles can delay players' chances of winning by either gaining enough info to"
        + " stop them or forcing players to do things they can't.";
    private const string ICDescription = "Impostor (Concealing) roles specialise in hiding information from others. If there is no new information, it's probably their work.";
    private const string IKDescription = "Impostor (Killing) roles have an addition ability to kill. Be careful of them as large numbers of dead bpdies will start to pile up with "
        + "them around.";
    private const string NBDescription = "Neutral (Benign) roles are special roles that have the capability to win with anyone, as long as a certain condition is fulfilled by the" +
        " end of the game.";

    private const string NKDescription = "Neutral (Killing) roles are roles that have the ability to kill and do not side with anyone. Each role has a special way to kill and gain "
        + "large body counts in one go. Steer clear of them if you don't want to die.";
    private const string NEDescription = "Neutral (Evil) roles are roles whose objectives clash with those of other roles. As such, you need to ensure they don't have a chance at" +
        " winning or when they do win, you have their cooperation.";
    private const string NCDescription = "Neutral (Chaos) roles are roles whom simply want the world to devolve into utter chaos for everyone.";
    private const string NADescription = "Neutral (Apocalypse) roles are powerful roles that have a certain objective." +
    " Once this objective is met, Apocalypse may utilize their roles and start a new dawn.";

    public string AlignmentName { get; }
    public Alignment Alignment { get; }

    public AlignmentInfo(Alignment alignmentEnum, bool header = false) : base(alignmentEnum.AlignmentName(), "", "", Colors.Alignment, InfoType.Alignment, header)
    {
        Alignment = alignmentEnum;
        (Short, Description, AlignmentName) = Alignment switch
        {
            Alignment.CrewmateAstral => ("CA", CADescription, "Astral"),
            Alignment.CrewmateInvestigative => ("CI", CIDescription, "Investigative"),
            Alignment.CrewmateProtective => ("CrP", CrPDescription, "Protective"),
            Alignment.CrewmateKilling => ("CK", CKDescription, "Killing"),
            Alignment.CrewmateChaos => ("CC", CCDescription, "Chaos"),
            Alignment.CrewmatePower => ("CrPow", CrPowDescription, "Power"),
            Alignment.CrewmateSupport => ("CS", CSDescription, "Support"),
            
            Alignment.NeutralBen => ("NB", NBDescription, "Benign"),
            Alignment.NeutralEvil => ("NE", NEDescription, "Evil"),
            Alignment.NeutralChaos => ("NC", NCDescription, "Chaos"),
            Alignment.NeutralKill => ("NK", NKDescription, "Killing"),
            Alignment.NeutralApoc => ("NA", NADescription, "Apocalypse"),

            Alignment.ImpostorSupport => ("IS", ISDescription, "Support"),
            Alignment.ImpostorConcealing => ("IC", ICDescription, "Conceal"),
            Alignment.ImpostorKill => ("IK", IKDescription, "Killing"),
            _ => ("Invalid", "Invalid", "Invalid")
        };
    }

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += $"Name: {Alignment.AlignmentName(true)}";
        result += "\n" + ColorIt($"Short Form: {Short}");
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}

public class ModifierInfo : Info
{
    public string AppliesTo { get; }
    public RoleEnum Modifier { get; }

    public ModifierInfo(string name, string shortF, string description, string applies, UColor color, RoleEnum modifier, bool header = false) : base(name, shortF, description, color,
        InfoType.Modifier, header)
    {
        AppliesTo = applies;
        Modifier = modifier;
    }

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += ColorIt($"Name: {Name}");
        result += "\n" + ColorIt($"Short Form: {Short}");
        result += "\n" + ColorIt(Utils.WrapText($"Applies To: {AppliesTo}"));
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}
/*
public class AbilityInfo : Info
{
    public string AppliesTo { get; }
    public RoleEnum Ability { get; }

    public AbilityInfo(string name, string shortF, string description, string applies, UColor color, RoleEnum ability, bool header = false) : base(name, shortF, description, color,
        InfoType.Ability, header)
    {
        AppliesTo = applies;
        Ability = ability;
    }

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += ColorIt($"Name: {Name}");
        result += "\n" + ColorIt($"Short Form: {Short}");
        result += "\n" + ColorIt(Utils.WrapText($"Applies To: {AppliesTo}"));
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}*/


/*public class SymbolInfo : Info
{
    public string Symbol { get; }

    public SymbolInfo(string name, string symbol, string description, UColor color, bool header = false) : base(name, "", description, color, header) => Symbol = symbol;

    public override void GuideEntry(out string result)
    {
        base.GuideEntry(out result);
        result += ColorIt($"Name: {Name}");
        result += "\n" + ColorIt($"Symbol: {Symbol}");
        result += "\n" + ColorIt(Utils.WrapText($"Description: {Description}"));
    }
}*/