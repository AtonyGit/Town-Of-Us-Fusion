using Il2CppSystem.Collections.Generic;
using System.Linq;
using Object = UnityEngine.Object;
using UColor = UnityEngine.Color;

namespace TownOfUsFusion.Patches;

public static class GuideInfo
{
    public static readonly List<RoleInfo> AllRoles = new()
    {
        new("Invalid", "Invalid", "Invalid", Alignment.None, Faction.None, "Invalid", Colors.Role, RoleEnum.None, "Invalid"),

        new("Altruist", "Alt", "The Altruist is capable of reviving dead players. After a set period of time, the player will be revived, if the revival isn't interrupted. Once a player is "
            + "revived, all evil players will be notified of the revival and will have an arrow pointing towards the revived player. The Altruist sacrifices themselves on the last use of " +
            "their ability. If the revived player has a Lover and both die together, the Lover is also revived.", Alignment.CrewmateProtective, Faction.Crewmates, Colors.Altruist, RoleEnum.Altruist),
        new("Crewmate", "Crew", "Just a plain Crewmate with no abilities and only spawns if all the other roles are taken or set to spawn in Custom mode.", Alignment.None, Faction.Crewmates, Colors.Crewmate, RoleEnum.Crewmate),
        new("Detective", "Det", "The Detective can examine other players for bloody hands and footprints. If the examined player has killed recently, the Detective will be alerted about it. "
            + "Once examined, the player's footprints will be visible to the Detective. Framed players will always appear to have bloody hands.", Alignment.CrewmateInvestigative, Faction.Crewmates, Colors.Detective, RoleEnum.Detective),
        new("Engineer", "Engi", "The Engineer can fix sabotages from anywhere on the map and use vents to get across the map easily.", Alignment.CrewmateSupport, Faction.Crewmates, 
            Colors.Engineer, RoleEnum.Engineer),
        new("Mayor", "Mayo (XD)", "The Mayor can reveal themselves as the Mayor to other players. Upon doing so, the value of their vote increases. A revealed Mayor cannot be protected, " +
            "but can be revived.", Alignment.CrewmatePower, Faction.Crewmates, Colors.Mayor, RoleEnum.Mayor),
        new("Medic", "Medic", "The Medic can give any player a shield that will grant them Powerful defense. The Medic can choose who they give thier shield to, and can take their shield " +
            "back if needed. Shielded players have a green ✚ next to their names.", Alignment.CrewmateProtective, Faction.Crewmates, Colors.Medic, RoleEnum.Medic),
        new("Medium", "Med", "The Medium can mediate to be able to see ghosts. If the Medium uses this ability, the Medium and the dead player will be able to see each other and communicate "
            + "with actions from beyond the grave!", Alignment.CrewmateAstral, Faction.Crewmates, Colors.Medium, RoleEnum.Medium),
        new("Monarch", "Mon", "The Monarch can appoint players as knights. When the next meeting is called, all knighted players will be announced. Knighted players will have the value of " +
            "their votes increased. For as long as a Knight is alive, the Monarch gets basic defense. Knighted players have a pinkish red κ next to their names. The Monarch is alerted when "
            + "a knight dies.", Alignment.CrewmatePower, Faction.Crewmates, Colors.Monarch, RoleEnum.Monarch),
        new("Mystic", "Mys", "The Mystic is notified when a player dies, as well as a rough estimate towards the location..", Alignment.CrewmateAstral, Faction.Crewmates, Colors.Mystic, RoleEnum.Mystic),
    };

    public static readonly List<ModifierInfo> AllModifiers = new()
    {
        new("Invalid", "Invalid", "Invalid", "Invalid", Colors.Modifier, ModifierEnum.None),
        new("Bait", "Bait", "The Bait's killer will be forced to self-report the Bait's body.", "Everyone except Troll, Vigilate, Altruist, Thief and Shifter", Colors.Bait,
            ModifierEnum.Bait, true),
        new("Lover", "Lover", "The Lovers are two players who are linked together. They gain the primary objective to stay alive together. In order to so, they gain access to a private" +
            " chat, only visible by them in between meetings. However, they can also win with their respective teams.", "Live to the final 3 with both Lovers still alive", "Everyone", "♥",
            Colors.Lovers, ModifierEnum.Lover),
            /*
        new("Coward", "Coward", "The Coward cannot report bodies.", "Everyone", Colors.Coward, ModifierEnum.Coward),
        new("Diseased", "Diseased", "Killing the Diseased increases all of the killer's cooldowns.", "Everyone except Troll and Altruist", Colors.Diseased, RoleEnum.Diseased),
        new("Drunk", "Drunk", "The Drunk's controls are inverted.", "Everyone", Colors.Drunk, ModifierEnum.Drunk),
        new("Dwarf", "Dwarf", "The Mini's body is smaller, but faster.", "Everyone", Colors.Mini, ModifierEnum.Dwarf),
        new("Giant", "Giant", "The Giant's body is bigger, but is slower", "Everyone", Colors.Giant, ModifierEnum.Giant),
        new("Useless", "UL", "The Useless modifier only appears when the Dwarf or Giant's speed and size multipliers have been set to 1. It literally does nothing.", "Everyone",
            Colors.Modifier, ModifierEnum.NoneModifier),
        new("Shy", "Shy", "The Shy player cannot call meetings.", "Everyone except Button Barries and roles who cannot call meetings", Colors.Shy, RoleEnum.Shy),
        new("Indomitable", "Ind", "The Indomitable player cannot be guessed.", "Everyone", Colors.Indomitable, RoleEnum.Indomitable),
        new("VIP", "VIP", "Everyone is alerted of the VIP's death through a flash of the VIP's role color and will have an arrow poiting towards the VIP's body.", "Everyone",
            Colors.VIP, ModifierEnum.VIP),
        new("Professional", "Prof", "The Professional has an extra life when guessing.", "Assassins", Colors.Professional, ModifierEnum.Professional),
        new("Astral", "Astral", "An Astral player is not teleported to the meeting table.", "Everyone", Colors.Astral, ModifierEnum.Astral),
        new("Yeller", "Yell", "The Yeller's location is revealed to everyone at all times.", "Everyone", Colors.Yeller, ModifierEnum.Yeller),
        new("Colorblind", "CB", "A colorblind player cannot tell the difference between players.", "Everyone", Colors.Colorblind, ModifierEnum.Colorblind),
        new("Volatile", "Vol", "A Volatile player will see random things happen to them and cannot distinguish real kill and flashes from the fake ones.", "Everyone",
            Colors.Volatile, ModifierEnum.Volatile)*/
    };

/*    public static readonly List<AbilityInfo> AllAbilities = new()
    {
        new("Invalid", "Invalid", "Invalid", "Invalid", "Invalid", "φ", Colors.Objectifier, RoleEnum.NoneObjectifier),
        new("Taskmaster", "TM", "The Taskmaster is basically a living Phantom. When a certain number of tasks are remaining, the Taskmaster is revealed to Intruders and the Syndicate" +
            " and the Crewmates only sees a flash to indicate the Taskmaster's existence.", "Finish tasks without dying or game ending", "Neutrals", "µ", Colors.Taskmaster,
            RoleEnum.Taskmaster, true),
        new("Lovers", "Lover", "The Lovers are two players who are linked together. They gain the primary objective to stay alive together. In order to so, they gain access to a private" +
            " chat, only visible by them in between meetings. However, they can also win with their respective teams.", "Live to the final 3 with both Lovers still alive", "Everyone", "♥",
            Colors.Lovers, RoleEnum.Lovers),
        new("Rivals", "Rival", "The Rivals cannot do anything to each other and must get the other one killed.", "Get the other rival killed without directly interfering, then live to the " +
            "final 2", "Everyone", "α", Colors.Rivals, RoleEnum.Rivals),
        new("Allied", "Ally", "An Allied Neutrals Killer now sides with either the Crewmates, Intruders or the Syndicate. In the case of the latter two, all faction members are shown who is "
            + "their Ally, and can no longer kill them. A Crewmates-Allied will have tasks that they must complete.", "Win with whichever faction they are aligned with", "Neutrals Killers", "ζ",
            Colors.Allied, RoleEnum.Allied),
        new("Fanatic", "CF (means Crewmates Fanatic)", "When attacked, the Fanatic joins whichever faction their attacker belongs to. From then on, their alliance sits with said faction.",
            "Get attacked by either the Intruders or the Syndicate to join their team", "Crewmates", "♠", Colors.Fanatic, RoleEnum.Fanatic),
        new("Overlord", "Ov", "Every meeting, for as long as an Overlord is alive, players will be alerted to their existence. The game ends if the Overlord lives long enough. All " +
            "alive Overlords win together.", "Survive a set amount of meetings", "Neutrals", "β", Colors.Overlord, RoleEnum.Overlord),
        new("Corrupted", "Corr", "The Corrupted is a member of the Crewmates with the alignment of a Neutrals Killer. On top of their base role's attributes, they also gain a kill button. Their " +
            "win condition is so strict that not even Neutrals Benigns or Evils can be spared. Corrupted adds a level of attack to the applied Crewmates.", "Kill everyone", "Crewmates", "δ",
            Colors.Corrupted, RoleEnum.Corrupted),
        new("Traitor", "CT (means Crewmates Traitor)", "The Traitor is a member of the Crewmates who must finish their tasks to switch sides. Upon doing so, they will either join the Intruders "
            + "or the Syndicate, and will win with that faction. If the Traitor is the only person in their new faction, they become a Betrayer, losing their original role's abilities "
            + "and gaining the ability to kill in the process.", "Finish tasks to join either the Intruders or Syndicate", "Crewmates", "♣", Colors.Traitor, RoleEnum.Traitor),
        new("Mafia", "Maf", "The Mafia are a group of players with a linked win condition. They must kill anyone who is not a member of the Mafia. All Mafia win together.", "Kill anyone" +
            " who is not a member of the Mafia", "Everyone", "ω", Colors.Mafia, RoleEnum.Mafia),
        new("Linked", "Link", "The Linked players are a watered down pair of Lovers. They can help the other player win. As long as one of the links wins, the other does too, regardless " +
            "of how they won.", "Help the other link win", "Neutrals", "Ψ", Colors.Linked, RoleEnum.Linked),
        new("Defector", "Defect", "A Defector switches sides when they happen to be the last player alive in their original faction.", "Kill off anyone who opposes their new faction",
            "Intruders And Syndicate", "ε", Colors.Defector, RoleEnum.Defector)

        new("Assassin", "Assassin", "The Assassin can guess the layers of others. If they guess right, the target is killed mid-meeting and if they guess wrong, they die instead. The name " +
            "of the Assassin ability depends on the faction it affects. Bullseye is for Crewmates, Hitman is for Intruders, Slayer is for Neutrals and Sniper is for the Syndicate. Assassin adds "
            + "a level of attack to the applied Crewmates.", "Intruders, Crewmates, Syndicate, Neutrals (Killing), Neutrals (Harbinger) and Neutrals (Neophyte)", Colors.Assassin,
            RoleEnum.Assassin, true),
        new("Button Barry", "BB", "The Button Barry can call a meeting from anywhere on the map, even during sabotages. Calling a meeting during a sabotage will fix the sabotage.",
            "Everyone except roles who cannot call meetings", Colors.ButtonBarry, RoleEnum.ButtonBarry),
        new("Insider", "Ins", "The Insider will be able to view everyone's votes in meetings upon finishing their tasks. Only spawns if Anonymous Votes is turn on.", "Crewmates",
            Colors.Insider, RoleEnum.Insider),
        new("Multitasker", "MT", "When doing tasks, the Multitasker's task window is transparent.", "Roles with tasks", Colors.Multitasker, RoleEnum.Multitasker),
        new("Ninja", "Nin", "Ninjas don't lunge when killing.", "Killing roles", Colors.Ninja, RoleEnum.Ninja),
        new("Radar", "Radar", "The Radar always has an arrow pointing towards the nearest player.", "Everyone", Colors.Radar, RoleEnum.Radar),
        new("Torch", "Torch", "The Torch has Intruder vision at all times and can see the silhouettes of invisible players.", "Crewmates, Neutrals Evil and Benign roles, Neutrals and Neutrals"
            + " Killers when their respective lights are off", Colors.Torch, RoleEnum.Torch),
        new("Underdog", "UD", "The Underdog is an Intruder or Syndicate with prolonged cooldowns when with a teammate. When they are the only remaining member, they will have their " +
            "cooldowns shortened.", "Intruders and Syndicate", Colors.Underdog, RoleEnum.Underdog),
        new("Swapper", "Swap", "The Swapper can swap the votes on 2 players during a meeting. All the votes for the first player will instead be counted towards the second player and "
            + "vice versa.", "Crewmates", Colors.Swapper, RoleEnum.Swapper)
    };*/

    public static readonly List<FactionInfo> AllFactions = new()
    {
        new(Faction.None),
        new(Faction.Crewmates, true),
        new(Faction.Neutrals),
        new(Faction.Impostors)
    };

    public static readonly List<AlignmentInfo> AllAlignments = new()
    {
        new(Alignment.None),
        new(Alignment.CrewmateAstral, true),
        new(Alignment.CrewmateInvestigative, true),
        new(Alignment.CrewmateProtective, true),
        new(Alignment.CrewmateKilling, true),
        new(Alignment.CrewmateChaos, true),
        new(Alignment.CrewmatePower, true),
        new(Alignment.CrewmateSupport, true),
        
        new(Alignment.NeutralBenign),
        new(Alignment.NeutralEvil),
        new(Alignment.NeutralChaos),
        new(Alignment.NeutralKilling),
        new(Alignment.NeutralApocalypse),

        new(Alignment.ImpostorConcealing),
        new(Alignment.ImpostorKilling),
        new(Alignment.ImpostorSupport)
    };

/*    public static readonly List<GameModeInfo> AllModes = new()
    {
        new(GameMode.None),
        new(GameMode.Classic, true),
        new(GameMode.Vanilla),
        new(GameMode.AllAny),
        new(GameMode.KillingOnly),
        new(GameMode.TaskRace),
        new(GameMode.RoleList),
        new(GameMode.HideAndSeek),
        new(GameMode.Custom)
    };*/

 /*   public static readonly List<OtherInfo> AllOthers = new()
    {
        new("Invalid", "Invalid", "Invalid", UColor.red, "Invalid"),
        new("Role", "Role", "Roles decide your abilities and goals for the game. Every game, you are guaranteed to have a role as not having one basically means you cannot play the game.",
            Colors.Role),
        new("Objectifier", "Obj", "Objectifiers provide an alternate way for you to win, and sometimes they may override the your original win condition (see Corrupted and Mafia) or change" +
            " your win condition mid-game (see Traitor and Fanatic).", Colors.Objectifier),
        new("Modifier", "Mod", "Modifiers are passive afflictions, usually negative or benign in nature, that serve no purpose and are there for fun. It cam alter a player's gameplay based"
            + " on what they might have. For example, Baits and Diseased players would want to die for their modifiers to take effect.", Colors.Modifier),
        new("Ability", "Ab", "Abilities give you an additional ability on top of your original abilities, to help boost your chances of winning.", Colors.Ability),
        new("Faction", "Faction", "A faction is the team a role, by default, belongs to. There can be situations where one player can jump ship to another team. Roles in the Neutrals faction"
            + " don't have a team, namely the Neutrals (Evil) roles. Neutrals (Benign) roles can side with whoever, and Neutrals (Neophyte) roles form their own mini faction called a subfaction"
            + ". Neutrals (Killing) roles are generally solo, but can be toggled to side with each other.", Colors.Faction),
        new("Alignment", "Alignment", "Alignments are a general umbrella where certain roles from other factions fall under. Alignments are generally only used for classification purposes " +
            "and a role cannot change alignments at any point in the game.", Colors.Alignment)
    };

    public static readonly List<SymbolInfo> AllSymbols = new()
    {
        new("Invalid", "Invalid", "Invalid", UColor.red),
        new("Null", "φ", "This symbol is a placeholder for when one doesn't have an objectifier or a subfaction that they are a part of.", Colors.SubFaction),
        new("Shield", "✚", "Players who have shield deployed on them through a Medic or a Retributionist-Medic.", Colors.Medic, true),
        new("Knighted", "κ", "Players who have been knighted by a Monarch recieve this symbol.", Colors.Monarch),
        new("Trapped", "∮", "Players that have been trapped by a Trapper or a Retributionist-Trapper. Trapped players will have their interactor's roles logged and sent to the relevant " +
            "Trapper. If the trapped target is attacked, the trap will remove all of its logged roles and attack the attacker. The Trapper is notified if the trap attacked someone, and if " +
            "it didn't then they get a list of roles that interacted with their targets.", Colors.Trapper),
        new("Arsonist Doused", "Ξ", "Players who have been doused by an Arsonist. Doused players can be ignited by the Arsonist from anywhere.", Colors.Arsonist),
        new("Bounty", "Θ", "Targets of a Bounty Hunter will have this symbol on their name. All targets know that there is a bounty on their head.", Colors.BountyHunter),
        new("Cryomaniac Doused", "λ", "Players who have been doused by a Cryomaniac. Doused players can be frozen by the Arsonist from anywhere.", Colors.Cryomaniac),
        new("Bitton", "γ", "The symbol that means one is a part of the Undead subfaction.", Colors.Undead),
        new("Tormented", "§", "Players being tormented by an Executioner. Avoid ejecting them to increases your chances of winning.", Colors.Executioner),
        new("Watched", "★", "Players being watched by a Guardian Angel. Try to recruit them, or their target to your side to increase you chances of winnign.", UColor.white),
        new("Protected", "η", "Players being protected by their Guardian Angel.", UColor.white),
        new("Agonise", "π", "Players being agonised by a Guesser. If the player happens to be on your team, avoid revealing their role publicly to increase your chances of winning.",
            Colors.Guesser),
        new("Recruit", "$", "The symbol that means one is a part of the Cabal subfaction.", Colors.Cabal),
        new("Resurrected", "Σ", "The symbol that means one is a part of the Reanimated subfaction.", Colors.Reanimated),
        new("Infected", "ρ", "Players that have been infected by a Plaguebearer. Once everyone is infected, the Plaguebearer becomes Pestilence.", Colors.Plaguebearer),
        new("Plague", "米", "This symbol denotes how many stacks of the plague a certain player has.", Colors.Pestilence),
        new("Vested", "υ", "Survivors who currently have their vests active.", Colors.Survivor),
        new("Persuaded", "Λ", "The symbol that means one is a part of the Sect subfaction.", Colors.Sect),
        new("Framed", "ς", "Players who are framed by a Framer or Rebel-Framer. Framed players can die without triggering penalties for killers like Vigilante and Assassin.",
            Colors.Framer),
        new("Spellbound", "ø", "Players who have been spellbound by a Spellslinger or Rebel-Spellslinger. When all non-Syndicate players are spellbound, the game will immediately end in" +
            "the Spellslinger's victory.", Colors.Spellslinger),
        new("Blackmailed", "Φ", "Players who have been blackmailed by a Blackmailer or Godfather-Blackmailer. Blackmailed players cannot speak in chat.", Colors.Blackmailer),
        new("Silenced", "乂", "Players who have been silenced by a Silencer or Rebel-Silencer. Silenced plaeyrs cannot see anything in chat aside from system messages.",
            Colors.Silencer),
        new("Flashed", "ㅇ", "Players who have been blinded by a Grenadier or a Godfather-Grenadier. Flashed players cannot see anything as their screen turns white. Players exempted from " +
            "being flashed will have their screen dull out a little to indicate that they got flashed.", Colors.Grenadier),
        new("Drived", "Δ", "The player who currently wields the Chaos Drive within the Syndicate faction.", Colors.Syndicate),
        new("Friend", "ξ", "This symbols indicates that they are on the same faction as the lcoal player, but beware them as they could still backstab you.", Colors.Faction),
        new("Marked", "χ", "Players who have been marked by the Ghoul. Marked players will die at the end of the next meeting.", Colors.Ghoul),
        new("First Dead", "Γ", "When the setting is enabled, the first person to die in the previous game gets a shield of protection in the next game for the first round.",
            Colors.FirstShield),
        new("On Alert", "σ", "Players who are on high alert. Players on alert will attack anyone who interacts with them.", Colors.Veteran),
        new("Crusaded", "τ", "Players being targeted by a Crusader. Crusaded players will attack anyone who interact with them, or if the Crusader holds the drive, everyone in a certain " +
            "radius.", Colors.Crusader),
        new("Ambushed", "人", "Players being targeted by an Ambusher. AMbushed players will attack anyone who interact with them.", Colors.Ambusher),
        new("Allied", "ζ", "Use to denote those who have the Allied objectifier. The color of this symbol denotes which faction they are a part of.", Colors.Allied),
        new("Corrupted", "δ", "Use to denote those who have the Corrupted objectifier.", Colors.Corrupted),
        new("Defector", "ε", "Use to denote those who have the Defector objectifier. The color of this symbol denotes which faction they are a part of.", Colors.Defector),
        new("Fanatic", "♠", "Use to denote those who have the Fanatic objectifier. The color of this symbol denotes which faction they are a part of.", Colors.Fanatic),
        new("Linked", "Ψ", "Use to denote those who have the Linked objectifier.", Colors.Linked),
        new("Lovers", "♥", "Use to denote those who have the Lovers objectifier.", Colors.Lovers),
        new("Mafia", "ω", "Use to denote those who have the Mafia objectifier.", Colors.Mafia),
        new("Overlord", "β", "Use to denote those who have the Overlord objectifier.", Colors.Overlord),
        new("Rivals", "α", "Use to denote those who have the Rivals objectifier.", Colors.Rivals),
        new("Taskmaster", "µ", "Use to denote those who have the Taskmaster objectifier.", Colors.Taskmaster),
        new("Traitor", "♣", "Use to denote those who have the Traitor objectifier. The color of this symbol denotes which faction they are a part of.", Colors.Traitor)
    };*/
}