﻿using System.Collections.Generic;
using UnityEngine;

namespace TownOfUsFusion.Patches.CustomHats
{
    public static class HatCache
    {
        public static Dictionary<string, Sprite> hatViewDatas = new Dictionary<string, Sprite>();
    }
}
