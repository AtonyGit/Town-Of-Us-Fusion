namespace TownOfUsFusion.Patches.CustomHats
{
    public class HatMetadataElement
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Artist { get; set; }
    }
}